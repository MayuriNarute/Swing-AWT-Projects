package com.Ui;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import com.Dao.MyConnection;
public class TransactionUi extends JFrame{
	JLabel l,lab1,l2,l3,l4;
	JPanel p1,p2;
	JButton back;
	Connection con=null;
	MyConnection m=new MyConnection();
	PreparedStatement ps=null;
	public TransactionUi(String uname){
		p1=new JPanel();
		p2=new JPanel();
		Font f2=new Font("Tahoma",Font.PLAIN,23);
		setTitle("View Transaction");
		BorderLayout bl=new BorderLayout();
		lab1=new JLabel("            Transactions Of "+uname);
		lab1.setFont(f2);
		lab1.setBounds(90, 30, 200, 80);
		p1.setBackground(Color.ORANGE);
		p1.setLayout(bl);
		add(p1,BorderLayout.NORTH);
		add(p2,BorderLayout.CENTER);
		p2.setBackground(Color.CYAN);
		p2.setLayout(new GridLayout(10,10,4,4));
		setVisible(true);
		setSize(600,600);
		p1.add(lab1);
		back=new JButton("Go Back");
		back.setBackground(Color.ORANGE);
		back.setBounds(10, 290, 80,40);
		back.setFont(f2);
		p2.add(back);
		back.addActionListener(new ActionListener() {		
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new WelcomeBank(uname);
				setVisible(false);			
			}
		});
		int i=0;
		con=m.getConnection();	
		try	{
			String mob=null;
			String ser=null;
			String user=null;
			int bal=0;
			ps=con.prepareStatement("select * from transactiongui where username=?");
			ps.setString(1, uname);
			ResultSet rs=ps.executeQuery();//select
			if(rs.next())	{
				i=1;
				user=rs.getString(1);
				mob=rs.getString(2);
				ser=rs.getString(3);
				bal=rs.getInt(4);
			}
			else			{
				System.out.println("Record not found...");
			}
			if(i==1)
			{
				l2=new JLabel("UserName -   "+"\t\t"+user);
				l3=new JLabel("Mobile No -   "+"\t\t"+mob);
				l2.setFont(f2);
				l3.setFont(f2);
				l4=new JLabel("Service Provider -    "+"\t\t"+ser);
				l4.setFont(f2);
				l=new JLabel("Amount -"+"\t\t"+bal);
				back=new JButton("Go Back");
				back.setBackground(Color.ORANGE);
				back.setBounds(50, 250, 80,40);
				back.setFont(f2);
				p2.add(l2);
				p2.add(l3);
				p2.add(l4);
				p2.add(back);
				back.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent arg0) {
						new WelcomeBank(uname);
						setVisible(false);
					}
				});
			}
			else	{
				JOptionPane.showMessageDialog(null, "Invalid Username & Password");

			}
			con.close();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
	}
}
