package com.Ui;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.Dao.MethodDao;
import com.Dao.MyConnection;
public class RechargeUi extends JFrame{
	JPanel pl,p2;
	JLabel l1,l2,l3,l4;
	JTextField t1,t2;
	JComboBox service;
	JButton rech,back;
	public RechargeUi(String uname){
		BorderLayout br=new BorderLayout();
		pl=new JPanel();
		p2=new JPanel();
		Font f2=new Font("Aerial",Font.BOLD,23);
		l4=new JLabel("Recharge Page");
		l4.setFont(f2);
		l4.setBounds(70, 40, 200, 40);
		p2.setBackground(Color.CYAN);
		add(p2,BorderLayout.NORTH);
		p2.add(l4);
		pl.setBackground(Color.ORANGE);
		setVisible(true);
		pl.setLayout(new GridLayout(4,2,2,2));
		setSize(500,500);
		l2=new JLabel("Phone Number :");
		l2.setFont(f2);
		t1=new JTextField(10);
		t1.setFont(f2);
		l3=new JLabel("Service Provider :");
		l3.setFont(f2);
		String sp[]= {"Vodafone","Jio","Airtel","Idea"};
		service=new JComboBox(sp);
		service.setFont(f2);
		l1=new JLabel("Enter Balance :");
		l1.setFont(f2);
		t2=new JTextField(20);
		t2.setFont(f2);
		rech=new JButton("Recharge");
		rech.setFont(f2);
		rech.setBackground(Color.CYAN);
		rech.setBounds(280, 280,100,40);
		back=new JButton("Go Back");
		back.setBackground(Color.CYAN);
		back.setBounds(300, 280, 100,40);
		back.setFont(f2);
		pl.add(l2);
		pl.add(t1);
		pl.add(l3);
		pl.add(service);
		pl.add(l1);
		pl.add(t2);
		pl.add(rech);
		pl.add(back);
		add(pl);
		rech.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					MethodDao m=new MethodDao();
					int bal=m.retrive(uname);
					String str1=t2.getText();
					int n1=Integer.parseInt(str1);
					int ans=bal-n1;
					if(ans<n1)
					{
						JOptionPane.showMessageDialog(rech, "Insufficient Balance in Your Account");

					}
					else
					{
					m.updaterecharge(uname, ans);
					JOptionPane.showMessageDialog(rech, "Recharge SuccessFully");
					m.transaction(uname,t1.getText(),service.getSelectedItem().toString(),n1);

					}
			}
		});
		back.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new WelcomeBank(uname);
				setVisible(false);
			}
		});
	}
}
