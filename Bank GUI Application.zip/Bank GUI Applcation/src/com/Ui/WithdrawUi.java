package com.Ui;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import com.Dao.MethodDao;
import com.Dao.MyConnection;
public class WithdrawUi extends JFrame{
	private JPanel contentPane;
	private JTextField textField;
	private JLabel lblEnterNewPassword;
	Connection con=null;
	MyConnection m=new MyConnection();
	PreparedStatement ps=null;
	public WithdrawUi(String uname) {
		setBounds(450, 360, 1024, 234);
		setVisible(true);
		setSize(900,900);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.setBackground(Color.CYAN);
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.PLAIN, 30));
		textField.setBounds(450, 35, 400, 50);
		contentPane.add(textField);
		textField.setColumns(10);
		JButton btnSearch = new JButton("Enter");
		JButton back=new JButton("Go Back");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String pstr = textField.getText();
				MethodDao m=new MethodDao();
				int n1=Integer.parseInt(pstr);
				int bal=m.retrive(uname);
				int finalbal=bal-n1;
				if(bal < n1)
				{
					JOptionPane.showMessageDialog(btnSearch, "Insufficient Balance in Your Account");
				}
				m.updaterecharge(uname, finalbal);
				JOptionPane.showMessageDialog(btnSearch, "Amount Withdraw SuccessFully..");
			}
		});
		back.addActionListener(new ActionListener() {		
			@Override
			public void actionPerformed(ActionEvent e) {
				new WelcomeBank(uname);
				setVisible(false);
				
			}
		});
		btnSearch.setFont(new Font("Tahoma", Font.PLAIN, 29));
		btnSearch.setBackground(Color.ORANGE);
		btnSearch.setBounds(400, 127, 170, 59);
		back.setFont(new Font("Tahoma", Font.PLAIN, 29));
		back.setBackground(Color.ORANGE);
		back.setBounds(400, 200, 170, 59);
		contentPane.add(btnSearch);
		contentPane.add(back);
		lblEnterNewPassword = new JLabel("Enter Amount To Withdrawl :");
		lblEnterNewPassword.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblEnterNewPassword.setBounds(8, 30, 390, 67);
		contentPane.add(lblEnterNewPassword);
	}
}
