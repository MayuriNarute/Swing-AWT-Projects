package com.Ui;
import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.Dao.MyConnection;
public class ProfileUi extends JFrame{
    private static final long serialVersionUID = 1L;
	private JPanel p1,p2;
	JButton back;
	JLabel lab1,l2,l3,l4,l5,l6,l7,l8,l9,l10;
	Connection con=null;
	MyConnection m=new MyConnection();
	PreparedStatement ps=null;
	public ProfileUi(String uname){
		p1=new JPanel();
		p2=new JPanel();
		Font f2=new Font("Tahoma",Font.PLAIN,23);
		setTitle("Profile Page");
		BorderLayout bl=new BorderLayout();
		lab1=new JLabel("                Profile Of "+uname);
		lab1.setFont(f2);
		lab1.setBounds( 70, 40, 200, 80);
		p1.setBackground(Color.ORANGE);
		p1.setLayout(bl);
		add(p1,BorderLayout.NORTH);
		add(p2,BorderLayout.CENTER);
		p2.setBackground(Color.CYAN);
		p2.setLayout(new GridLayout(10,10,4,4));
		setVisible(true);
		setSize(500,500);
		p1.add(lab1);
		int i=0;
		con=m.getConnection();
		try{
			String str=null;
			String fname=null;
			String lname=null;
			String mobno=null;
			String user=null;
			String pass=null;
			String city=null;
			String state=null;
			int bal=0;
			ps=con.prepareStatement("select * from customergui where username=?");
			ps.setString(1, uname);
			ResultSet rs=ps.executeQuery();//select
			if(rs.next()){
				i=1;
				str=rs.getString(1);
				fname=rs.getString(2);
				lname=rs.getString(3);
				mobno=rs.getString(4);
				user=rs.getString(5);
				pass=rs.getString(6);
				bal=rs.getInt(7);
				city=rs.getString(8);
				state=rs.getString(9);					
			}
			else{
				System.out.println("Record not found...");
			}
			if(i==1){
				l2=new JLabel("Registration No -   "+"\t\t"+str);
				l3=new JLabel("FirstName -   "+"\t\t"+fname);
				l2.setFont(f2);
				l3.setFont(f2);
				l4=new JLabel("LastName -    "+"\t\t"+lname);
				l4.setFont(f2);
				l5=new JLabel("Mobile No. -     "+"\t\t"+mobno);
				l5.setFont(f2);
				l6=new JLabel("Username -   "+"\t\t"+user);
				l6.setFont(f2);
				l7=new JLabel("Password -    "+"\t\t"+pass);
				l7.setFont(f2);
				l8=new JLabel("Account Balance -   "+"\t\t"+bal);
				l8.setFont(f2);
				l9=new JLabel("City -   "+"\t\t"+city);
				l9.setFont(f2);
				l10=new JLabel("State -   "+state);
				l10.setFont(f2);
				back=new JButton("Go Back");
				back.setBackground(Color.ORANGE);
				back.setBounds(10, 290, 80,40);
				back.setFont(f2);
				p2.add(l2);
				p2.add(l3);
				p2.add(l4);
				p2.add(l5);
				p2.add(l6);
				p2.add(l7);
				p2.add(l8);
				p2.add(l9);
				p2.add(l10);
				p2.add(back);
				back.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent arg0) {
						new WelcomeBank(uname);
						setVisible(false);
					}
				});				
			}
			else{
				JOptionPane.showMessageDialog(null, "Invalid Username & Password");
			}
			con.close();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
	}
}
