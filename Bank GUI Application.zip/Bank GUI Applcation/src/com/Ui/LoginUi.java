package com.Ui;
import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.Dao.MethodDao;
import com.Dao.MyConnection;
import com.Main.BankAppMain;
public class LoginUi  extends JFrame{
    private static final long serialVersionUID = 1L;
	JPanel p;
	JLabel l1,l2,l3;
	JTextField t1;
	JPasswordField t2;
	JButton log,home;
	MyConnection m=new MyConnection();
	Connection con=null;
	PreparedStatement ps=null;
	public LoginUi(){
		Font f=new Font("Tahoma",Font.PLAIN,30);
		Font f2=new Font("Tahoma",Font.PLAIN,23);
		p=new JPanel();
		p.setBackground(Color.CYAN);
		l1=new JLabel("Login Page");
		l1.setFont(f);
		l2=new JLabel("UserName :");
		l2.setFont(f2);
		t1=new JTextField();
		l3=new JLabel("PassWord :");
		t1.setFont(f2);
		l3.setFont(f2);
		t2=new JPasswordField();
		t2.setFont(f2);
		log=new JButton("Login");
		log.setFont(f2);
		home=new JButton("Home Page");
		home.setFont(f2);
		l1.setBounds( 70, 40, 200, 40);
		l2.setBounds(70, 110, 150, 30);//username label
		t1.setBounds(70,140, 200, 40);//textfield
		l3.setBounds(70, 190, 150, 30);//password label
		t2.setBounds(70, 230, 200, 40);//textfield
		log.setBounds(80, 330, 100,50);
		log.setBackground(Color.YELLOW);
		home.setBackground(Color.YELLOW);
		home.setBounds(200, 330, 180,50);
		add(p);
		p.setLayout(null);
		setVisible(true);
		setSize(500,500);
		p.add(l1);
		p.add(l2);
		p.add(t1);
		p.add(l3);
		p.add(t2);
		p.add(log);
		p.add(home);
		String str1=t1.getText();
		log.addActionListener(new ActionListener() {		
			@Override
			public void actionPerformed(ActionEvent arg0) {
				MethodDao m=new MethodDao();
				String uname=t1.getText();
				String pass=t2.getText();
				int i=m.LoginCustomer(uname, pass);
				if(i==1){
					JOptionPane.showMessageDialog(null, "Login SuccessFully..");
					new WelcomeBank(uname);
					setVisible(false);
				}
				else{
					JOptionPane.showMessageDialog(null, "Invalid Username & Password");
				}
				
			}
		});
		home.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new BankAppMain();
				setVisible(false);
				
			}
		});	
	}
}
