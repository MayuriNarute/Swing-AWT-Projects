package com.Ui;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import com.Dao.MethodDao;
import com.Dao.MyConnection;
public class DepositUi extends JFrame {
	JTextField t1;
	JLabel l1,l2;
	JPanel p1;
	JButton enter,back;
	Connection con=null;
	MyConnection m=new MyConnection();
	PreparedStatement ps=null;
	public DepositUi(String uname){
		setBounds(450, 360, 1024, 234);
		setVisible(true);
		setSize(900,900);
		p1 = new JPanel();
		p1.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(p1);
		p1.setLayout(null);
		p1.setBackground(Color.CYAN);
		t1 = new JTextField();
		t1.setFont(new Font("Tahoma", Font.PLAIN, 30));
		t1.setBounds(440, 35, 400, 50);
		p1.add(t1);
		t1.setColumns(10);
		enter=new JButton("Enter");
		back=new JButton("Go Back");
		enter.setFont(new Font("Tahoma", Font.PLAIN, 29));
		enter.setBackground(Color.ORANGE);
		enter.setBounds(400, 127, 170, 59);
		back.setFont(new Font("Tahoma", Font.PLAIN, 29));
		back.setBackground(Color.ORANGE);
		back.setBounds(400, 200, 170, 59);
		p1.add(enter);
		p1.add(back);
		l1= new JLabel("Enter Money To Deposit:");
		l1.setFont(new Font("Tahoma", Font.PLAIN, 30));
		l1.setBounds(10, 30, 380, 67);
		p1.add(l1);
		enter.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				MethodDao m=new MethodDao();			
				String newbal=t1.getText();
				int n1=Integer.parseInt(newbal);
				int bal=m.retrive(uname);
				int finalbal=bal+n1;			
				m.updaterecharge(uname, finalbal);
				JOptionPane.showMessageDialog(enter, "Money Deposited SuccessFully..");
			}
		});
		back.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new WelcomeBank(uname);
				setVisible(false);
			}
		});
	}
}
