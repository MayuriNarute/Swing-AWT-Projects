package com.Ui;
import com.Dao.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.*;
import com.Main.BankAppMain;
public class RegisterGui extends JFrame implements ActionListener{
	JPanel pnl,pn2,pn3;
	JButton reg,home;
	JLabel l1,lrno,lfnm,llnm,lmob,lunm,lpass,lcity,lstate,lstbal;
	JTextField trno,tfnm,tlnm,tmob,tunm,tbal;
	JPasswordField tpass;
	JComboBox ccity;
	JList lststate;
	Connection con=null;
	MyConnection m=new MyConnection();
	PreparedStatement ps=null;
	public RegisterGui() {
		super("Register Page");
		Font f=new Font("Tahoma",Font.PLAIN, 24);
		setSize(800,800);
		setVisible(true);
		pnl=new JPanel();
		pn2=new JPanel();
		pn3=new JPanel();
		pn2.setBackground(Color.yellow);
		l1=new JLabel("| Register Page |");
		l1.setFont(f);
		pn3.setBackground(Color.CYAN);
		add(pn3,BorderLayout.CENTER);
		pn2.add(l1);
		add(pn2,BorderLayout.NORTH);
		pnl.setLayout(new GridLayout(10,5,2,2));
		pnl.setBackground(Color.CYAN);
		add(pnl);
		lrno=new JLabel("Registration No :");
		lrno.setFont(f);
		lfnm=new JLabel("FirstName :");
		lfnm.setFont(f);
		llnm=new JLabel("LastName :");
		llnm.setFont(f);
		lmob=new JLabel("Mobile No :");
		lmob.setFont(f);
		lunm=new JLabel("UserName :");
		lunm.setFont(f);
		lpass=new JLabel("Password :");
		lpass.setFont(f);
		lstbal=new JLabel("Account Balance :");
		lstbal.setFont(f);
		lcity=new JLabel("City :");
		lcity.setFont(f);
		lstate=new JLabel("State :");
		lstate.setFont(f);
		trno=new JTextField();
		trno.setFont(f);
		tfnm=new JTextField(20);
		tfnm.setFont(f);
		tlnm=new JTextField(20);
		tlnm.setFont(f);
		tmob=new JTextField(10);
		tmob.setFont(f);
		tunm=new JTextField(20);
		tunm.setFont(f);
		tpass=new JPasswordField(20);
		tpass.setFont(f);
		tbal=new JTextField(10);
		tbal.setFont(f);
		String ct[]= {"Mumbai","Pune","Nashik","Nagpur","Ahemdabad"};
		ccity=new JComboBox(ct);
		ccity.setFont(f);
		String st[]= {"Maharashtra","Gujarat"};
		lststate=new JList(st);
		lststate.setFont(f);
		reg=new JButton("REGISTER");
		reg.setForeground(Color.WHITE);
		home=new JButton("HOME PAGE");
		home.setForeground(Color.WHITE);
		reg.setBackground(Color.RED);
		reg.setFont(f);
		home.setBackground(Color.RED);
		home.setFont(f);
		pnl.add(lrno);
		pnl.add(trno);
		pnl.add(lfnm);
		pnl.add(tfnm);
		pnl.add(llnm);
		pnl.add(tlnm);
		pnl.add(lmob);
		pnl.add(tmob);
		pnl.add(lunm);
		pnl.add(tunm);
		pnl.add(lpass);
		pnl.add(tpass);
		pnl.add(lstbal);
		pnl.add(tbal);
		pnl.add(lcity);
		pnl.add(ccity);
		pnl.add(lstate);
		pnl.add(lststate);	
		pnl.add(reg);
		pnl.add(home);	
		reg.addActionListener(this);
		home.addActionListener(this);
	}
	@Override
	public void actionPerformed(ActionEvent e){
		if(e.getSource()==home){
			BankAppMain bm=new BankAppMain();
			this.dispose();
		}
		if(e.getSource()==reg){
			String id = trno.getText();
			String fname = tfnm.getText();
			String lname = tlnm.getText();
			String mob =tmob.getText();
			String unm = tunm.getText();
			String pass= tpass.getText();
			String str=tbal.getText();
			String city= ccity.getSelectedItem().toString();
			if(id.equals("") || fname.equals("") || lname.equals("") || mob.equals("") || 
			unm.equals("") || pass.equals("")
			|| city.equals("") || lststate.getSelectedValue().toString().equals("") 
			|| str.equals("")) {
				JOptionPane.showMessageDialog(reg, "Please Fill All The Details Correctly");
			}
			else{
				if(pass.matches("(?=(.*\\d){3})[a-zA-Z0-9]{8,}") && pass.length()== 8)
				{
					if(id.matches("[0-9]+") && mob.matches("[0-9]+")) 
					{
						if(fname.matches("^[a-zA-Z]*$") && lname.matches("^[a-zA-Z]*$")) 
						{
							if(unm.matches("^[a-zA-Z0-9]([._-](?![._-])|[a-zA-Z0-9]){3,18}[a-zA-Z0-9]$")) 
							{		
								if(mob.length()==10)
								{
									MethodDao m=new MethodDao();
									int bal=Integer.parseInt(str);

									int flag=m.Registercustomer(id, fname, lname, mob, unm, pass, bal, city,lststate.getSelectedValue().toString());
									if(flag==1)
									{
										JOptionPane.showMessageDialog(reg, "Register SuccessFully");
										new LoginUi();
										this.dispose();
									}
									else
									{
										JOptionPane.showMessageDialog(reg, "Customer ID or Username Already Exists..");

									}
								}else
								{
									JOptionPane.showMessageDialog(reg, "Mobile Number should be 10 digit Only..");

								}
							}else {
								JOptionPane.showMessageDialog(reg, "Please Enter Strong Username");
							}
						}else {
							JOptionPane.showMessageDialog(reg, "First & Last Name Should have Only Alphabets");
						}
					}else {
						JOptionPane.showMessageDialog(reg, "Customer Id & Age Should have Only Numbers");
					}
				}else {
					JOptionPane.showMessageDialog(reg, "Password Incredentials\nShould have to be 8 characters\n3 Digits and Alphabets");
				}
			}
		}
	}
}