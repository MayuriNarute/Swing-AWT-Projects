package com.Dao;
import java.sql.*;
public class MethodDao {

	Connection con=null;
	MyConnection m=new MyConnection();
	PreparedStatement ps1=null;
	public int Registercustomer(String id,String fnm,String lnm,String mob,String uname,String pass,int bal,String city,String state )
	{
		con=m.getConnection();
		int i=0,flag=0;
		try{
			PreparedStatement ps1=con.prepareStatement("insert into Customergui values(?,?,?,?,?,?,?,?,?)");
			ps1.setString(1, id);
			ps1.setString(2,fnm);
			ps1.setString(3, lnm);

			ps1.setString(4, mob);
			ps1.setString(5, uname);
			ps1.setString(6, pass);
			ps1.setInt(7,bal);
			ps1.setString(8,city);

			ps1.setString(9,state);

			i=ps1.executeUpdate();
			if(i>0){
				flag=1;
				System.out.println("Customer register successfully..");
			}
			else{
				System.out.println("customer not register");
			}
			con.close();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		return flag;
	}
	public int LoginCustomer(String uname,String pass)
	{
		con=m.getConnection();
		int i=0;
		try{
			PreparedStatement ps1=con.prepareStatement("select * from customergui where username=? and password=?");
			ps1.setString(1,uname);
			ps1.setString(2,pass);
			
			ResultSet rs=ps1.executeQuery();//select
			while(rs.next()==true){
				i=1;
				rs.getString(1);
				rs.getString(2);
				rs.getString(3);
				rs.getString(4);
				rs.getString(5);
				rs.getString(6);
				rs.getInt(7);
				rs.getString(8);
				rs.getString(9);
			}		
			con.close();
		}
		catch(Exception ex){
			System.out.println(ex);
		}
		return i;
	}
	public int retrive(String uname)
	{
		int balance=0;
		con=m.getConnection();
		try{
			ps1=con.prepareStatement("select balance from customergui where username=?");
			ps1.setString(1,uname);
			//ps.setString(2,bal);
			ResultSet rs=ps1.executeQuery();//select
			if(rs.next()==false){
				balance=0;
			}
			else{
				balance=rs.getInt(1);
			}
			con.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return balance;
	}
	public void updaterecharge(String uname,int balance)
	{
		con=m.getConnection();
		try {
			int i=0;
			PreparedStatement ps2=con.prepareStatement("update customergui set balance=? where username=?");
			ps2.setInt(1,balance);
			ps2.setString(2,uname);
			System.out.println(balance);
			i=ps2.executeUpdate();

			if(i>0) {
				System.out.println("recharge successfully");
			}
			else
			{
				System.out.println("failed to recharge");
			}
			con.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	public void transaction(String uname,String mobno,String service,int balnew)
	{
		con=m.getConnection();
		try
		{
			int i=0;
			PreparedStatement ps2=con.prepareStatement("insert into transactiongui values(?,?,?,?)");
			ps2.setString(1,uname);
			ps2.setString(2,mobno);
			ps2.setString(3,service);
			ps2.setInt(4, balnew);
			i=ps2.executeUpdate();
			if(i>0){
				System.out.println("Data Save");
			}
			else{
				System.out.println("Data not save");
			}
			con.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	public int getMob(String uname)
	{
		String mobno=null;
		con=m.getConnection();
		try{
			PreparedStatement ps=con.prepareStatement("select mobno from customergui where username=?");
			ps.setString(1,uname);
		
			ResultSet rs=ps.executeQuery();
			if(rs.next()==true)
			{
				rs.getString(1);
				mobno=rs.getString(2);
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		int mob=Integer.parseInt(mobno);
		return mob;

	}
	public int getpass(String uname)
	{
		con=m.getConnection();
		String pass=null;
		try{
			PreparedStatement ps=con.prepareStatement("select password from customergui where username=?");
			ps.setString(1,uname);
		
			ResultSet rs=ps.executeQuery();
			if(rs.next()==true){
				rs.getString(1);
				pass=rs.getString(2);
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		int psw=Integer.parseInt(pass);
		return psw;
	}
}
