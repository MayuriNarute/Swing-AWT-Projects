package com.Dao;
import java.sql.*;
public class MyConnection {

	public Connection getConnection(){
		Connection con=null;
		try
		{
			Class.forName("oracle.jdbc.OracleDriver");
			//step2- connection to database
			String url="jdbc:oracle:thin:@localhost:1521:XE";
			String uname="System";
			String pass="3840";
			//step2-connection to database
			con=DriverManager.getConnection(url,uname,pass);
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return con;
	}
}
