package com.Main;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.Ui.*;
public class BankAppMain extends JFrame implements ActionListener{
    private static final long serialVersionUID = 1L;
	JButton login,register;
	JLabel l1,l2;
	JPanel p1;
	public BankAppMain(){
		p1=new JPanel();
		Font f=new Font("Tahoma",Font.PLAIN,35);
		p1.setBackground(Color.PINK);
		p1.setLayout(null);
		setSize(600,600);
		setVisible(true);
		p1.setAlignmentX(Component.CENTER_ALIGNMENT);
		l2=new JLabel("---NOBLE TRANSFER BANK---");
		l2.setBounds(100, 10, 900, 300);
		l1=new JLabel("Welcome to Our Home-Page");
		l1.setBounds(100, 30,800, 100);
		l1.setFont(f);
		l2.setFont(f);
		login=new JButton("Login");
		login.setBackground(Color.CYAN);
		login.setBounds(80, 200,200, 50);
		login.setFont(f);
		register=new JButton("Register");
		register.setBackground(Color.CYAN);
		register.setBounds(80, 300,200, 50);
		register.setFont(f);
		add(p1);
		p1.add(l1);
		p1.add(l2);
		p1.add(login);
		p1.add(register);
		login.addActionListener(this);
		register.addActionListener(this);
	}
	public void actionPerformed(ActionEvent e){
		if(e.getSource()==login){
			new LoginUi();
			this.dispose();
		}
		if(e.getSource()==register){
			new RegisterGui();
			this.dispose();
		}	
	}
	public static void main(String[] args){
		new BankAppMain();
	}
}
