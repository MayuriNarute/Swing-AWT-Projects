//The Abstract Window Toolkit (AWT) is an API which supports Graphical User 
//Interface (GUI) programming
//Contains all of the classes for creating user interfaces 
//and for painting graphics and images.
import java.awt.event.*;

import javax.swing.JTextField;
import javax.swing.border.Border;

import java.awt.*;
public class Calculator implements ActionListener{
	TextField tno1,tno2,tans;
	Label lno1,lno2,lno3;
	Button btnadd,btnsub,btnmult,btnreset,btndiv,btnexit;
	Color cyan;
	Panel pn1;
	Frame frm;
	public Calculator()
	{
		frm=new Frame("Calculator");
		frm.setVisible(true);
		frm.setSize(600,600);
		pn1=new Panel();
		
		Font myFont = new Font("Serif",Font.BOLD,25);
		GridLayout g1=new GridLayout(6,2);
		pn1.setLayout(g1);
		
		lno1=new Label("Number 1 :");
		lno1.setBackground(Color.CYAN);
		lno1.setFont(myFont);

		
		lno2=new Label("Number 2 :");
		lno2.setBackground(Color.CYAN);
		lno2.setFont(myFont);
		
		
		lno3=new Label("Answer :");
		lno3.setBackground(Color.CYAN);
		lno3.setFont(myFont);
		
		
		tno1=new TextField(10);
		tno1.setFont(myFont);

		
		tno2=new TextField(10);
		tno2.setFont(myFont);
		
		tans=new TextField(10);
		tans.setFont(myFont);
		
		frm.add(pn1);
		
		pn1.add(lno1);
		pn1.add(tno1);
		pn1.add(lno2);
		pn1.add(tno2);
		pn1.add(lno3);
		pn1.add(tans);
		
		btnadd=new Button("+");
		btnadd.setFont(myFont);
		btnadd.setBackground(Color.PINK);
		
		btnsub=new Button("-");
		btnsub.setFont(myFont);
		btnsub.setBackground(Color.PINK);
		
		btnmult=new Button("*");
		btnmult.setFont(myFont);
		btnmult.setBackground(Color.PINK);
		
		btndiv=new Button("/");
		btndiv.setFont(myFont);
		btndiv.setBackground(Color.PINK);
		
		btnreset=new Button("C");
		btnreset.setFont(myFont);
		btnreset.setBackground(Color.PINK);
		
		btnexit=new Button("Exit");
		btnexit.setFont(myFont);
		btnexit.setBackground(Color.PINK);
		
		
		pn1.add(btnadd);
		pn1.add(btnsub);
		pn1.add(btnmult);
		pn1.add(btndiv);
		pn1.add(btnreset);
		pn1.add(btnexit);

		btnadd.addActionListener(this);
		btnsub.addActionListener(this);
		btnmult.addActionListener(this);
		btndiv.addActionListener(this);
		btnreset.addActionListener(this);
		btnexit.addActionListener(this);	
	}
	@Override
	public void actionPerformed(ActionEvent e)
	{

		if(e.getSource()==btnadd)
		{
			String s1=tno1.getText();
			String s2=tno2.getText();
			int n1=Integer.parseInt(s1);
			int n2=Integer.parseInt(s2);
			int add=n1+n2;
			tans.setText(Integer.toString(add));

		}
		if(e.getSource()==btnsub)
		{
			String s1=tno1.getText();
			String s2=tno2.getText();
			int n1=Integer.parseInt(s1);
			int n2=Integer.parseInt(s2);
			int add=n1-n2;
			tans.setText(Integer.toString(add));

		}
		if(e.getSource()==btnmult)
		{
			String s1=tno1.getText();
			String s2=tno2.getText();
			int n1=Integer.parseInt(s1);
			int n2=Integer.parseInt(s2);
			int add=n1*n2;
			tans.setText(Integer.toString(add));

		}
		if(e.getSource()==btndiv)
		{
			String s1=tno1.getText();
			String s2=tno2.getText();
			int n1=Integer.parseInt(s1);
			int n2=Integer.parseInt(s2);
			int add=n1/n2;
			tans.setText(Integer.toString(add));

		}
		if(e.getSource()==btnreset)
		{
			tno1.setText("");
			tno2.setText("");
			tans.setText("");
		}
		if(e.getSource()==btnexit)
		{
			System.exit(0);
		}
	}

}
